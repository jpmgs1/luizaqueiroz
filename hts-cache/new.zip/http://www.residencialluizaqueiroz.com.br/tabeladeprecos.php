<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Residencial Luiza Queiroz</title>
<link href="css/estilo.css" rel="stylesheet" type="text/css">
<link rel="stylesheet" type="text/css" href="shadowbox/shadowbox.css" />
<link href="SpryAssets/SpryValidationTextField.css" rel="stylesheet" type="text/css">
<script type="text/javascript">
var userAgent = navigator.userAgent.toLowerCase();
var devices = new Array('nokia','iphone','blackberry','sony','lg',
'htc_tattoo','samsung','symbian','SymbianOS','elaine','palm',
'series60','windows ce','android','obigo','netfront',
'openwave','mobilexplorer','operamini');
var url_redirect = 'http://www.residencialluizaqueiroz.com.br/mobile';
function mobiDetect(userAgent, devices) {
for(var i = 0; i < devices.length; i++) {
if (userAgent.search(devices[i]) > 0) {
return true;
}
}
return false;
}

if (mobiDetect(userAgent, devices)) {
window.location.href = url_redirect;
}
</script>

<script src="SpryAssets/SpryValidationTextField.js" type="text/javascript"></script>
<script src="js/jquery-1.7.2.min.js"></script>
<script src="shadowbox/shadowbox.js"></script>


<script type='text/javascript'>
Shadowbox.init({
overlayColor: "#000",
overlayOpacity: 0.8,
});
</script>

<script type="text/javascript">

  var _gaq = _gaq || [];
  _gaq.push(['_setAccount', 'UA-40291205-1']);
  _gaq.push(['_trackPageview']);

  (function() {
    var ga = document.createElement('script'); ga.type = 'text/javascript'; ga.async = true;
    ga.src = ('https:' == document.location.protocol ? 'https://ssl' : 'http://www') + '.google-analytics.com/ga.js';
    var s = document.getElementsByTagName('script')[0]; s.parentNode.insertBefore(ga, s);
  })();

</script>
</head>

<body id="pg-home">
<div id="container">
<div id="content">

 


<div id="sidebar">

<div id="logo">
<a href="index.php"><img src="pics/logo.jpg" width="145" height="206" /></a>
</div>

<div id="nav">
<ul>
<li><a href="index.php">Home</a></li>
<li><a href="empreendimento.php">Empreendimento</a></li>
<li><a href="imagens.php">Imagens</a></li>
<li><a href="localizacao.php">Localização</a></li>
<li><a href="tabeladeprecos.php">Tabela de Preços</a></li>
<li><a href="contato.php">Contato</a></li>
</ul>
</div>  

<div id="marcas">
<img src="pics/marcas.png" width="201" height="109" border="0" usemap="#Map" />
<map name="Map" id="Map">
<area shape="rect" coords="100,14,179,96" href="http://www.aliancaimobiliaria.com.br/" target="_blank" />
</map>
</div>


</div>

<div id="conteudo-folder">

  <img style="position:absolute;top:230px;left:45px;" src="pics/tabela.jpg" width="580" height="212" />
  
  </div>



</div>
</div>

</body>
</html>

